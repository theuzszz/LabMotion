# Código-fonte do LabMotion

Para jogar, use a entrega HTML portátil; não é necessário compilar.

Para desenvolver: instale Node compatível com package.json e pnpm; execute
`pnpm install` e `pnpm dev`. A configuração `.openai/hosting.json` é incluída
porque vite.config.ts a importa. Ela contém somente identificação do projeto
e campos de armazenamento sem credenciais. Esta cópia não publica nada.

Para gerar a versão portátil: `pnpm exec vite build --config vite.portable.config.ts`
e `node portable/export-single.mjs CAMINHO_DE_SAIDA.html`.

Os scripts, estilos e fonte são incorporados no HTML. A licença Fredoka acompanha
o diretório portable. Não há arquivos .env, credenciais, dependências instaladas
ou caches neste pacote. Não substitua a configuração por credenciais pessoais
ao compartilhar. Publicação externa é uma operação separada.
